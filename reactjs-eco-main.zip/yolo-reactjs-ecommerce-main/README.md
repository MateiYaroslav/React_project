# React Ecommerce Web Shop

    Build React Ecommerce Web Shop with SASS

# Video

    Part 01: https://youtu.be/fUdrXQ72670

    Part 02: https://youtu.be/I8GRy7GA3lU

# Description

    Build React Ecommerce Web Shop with SASS

# Resource

    Google font: https://fonts.google.com/

    Boxicons: https://boxicons.com/

    Images: https://unsplash.com/

# Preview

!["React Ecommerce Web Shop"](https://user-images.githubusercontent.com/67447840/128343064-cdbb2694-c147-4a11-8246-bfc757fe9f74.jpg "React Ecommerce Web Shop")

!["React Ecommerce Web Shop"](https://user-images.githubusercontent.com/67447840/128343137-27808566-9d5e-440d-82cb-11d0a1aa8509.png "React Ecommerce Web Shop")

!["React Ecommerce Web Shop"](https://user-images.githubusercontent.com/67447840/128343189-790482b4-6bdb-46dc-9d31-bf41f580e39d.png "React Ecommerce Web Shop")
